// This is a TypeScript compatibility file
// It will re-export all exports from schema.js
export * from './schema.js';