{pkgs}: {
  deps = [
    pkgs.postgresql
  ];
}
